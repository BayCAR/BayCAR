rm(list = ls())


# function for calculating posterior probability of a treatment has the lowest percentage, given the new subject is assigned to this treatment;
# The input is the counts of all treatments
Next.fun=function(frq)
{if (all(frq==0)) {frq=1+frq}

  if (length(frq)==2)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2 )
  }

  if (length(frq)==3)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3)
  }

  if (length(frq)==4)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[4]+.5, frq[4]+1+.5)}
  P4=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3, P4)
  }

  if (length(frq)==5)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[4]+.5, frq[4]+1+.5)}
  P4=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[5]+.5, frq[5]+1+.5)}
  P5=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3, P4, P5)
  }

  if (all(allP==0)) {allP=1+allP}

  whtrt= names(as.data.frame(frq))[which(allP==max(allP))]
  whtrt=sample(whtrt,1)
  return(list(whtrt, allP))
}

# The function for calculating biasing randomization probability
FNN.out=function(data, i, covj, ratio, weights)
{ink=0
if (covj=="group") {tg=t(table(data[,"group"]))} else
{tg= table(data[1:i,covj], data$group[1:i]) }
if (all(abs(tg[,1]-tg[,2])<1)) {ink=1}

gi=data[i, covj]
frq0=frq=t(tg[row.names(tg)==gi,])
if (all(frq==0)) {} else {frq=frq  /ratio    #*sum(ratio)/min(ratio)# *100
frq=frq*sum(frq0)/sum(frq)}
g.out=Next.fun(frq)
g.out[[2]]=g.out[[2]]^weights

return (list(g.out, ink))
}


FUN.BCAR=function(data, categorical.covariates, continuous.covariates, group.level, ratio, categorical.weights, continuous.weights, start.number, num.categories, pct.determinstic)
{ if (missing(num.categories)) {num.categories=4}
  if (missing(pct.determinstic)) {pct.determinstic=0.95}
  if (missing(start.number)) {start.number=15}
  if (missing(group.level)) {group.level=c("A", "B")}
  contin=PP=cPP=1
  if (missing(continuous.covariates)) {contin=0} else {qk=rep(num.categories+1, length(continuous.covariates))}
  if (missing(ratio)) {ratio=rep(1, length(group.level))}
  if (missing(categorical.weights)&!missing(categorical.covariates)) {categorical.weights=rep(1, length(categorical.covariates))}
  if (missing(continuous.weights)&!missing(continuous.covariates)) {continuous.weights=rep(1, length(continuous.covariates))}

  data$group=NA
  data$group[1:length(group.level)]=sample(group.level, length(group.level), replace = FALSE)
  start=(sum(!is.na(data$group))+1)

  if (missing(categorical.covariates)) {data$group[start:start.number]=sample(group.level, start.number-start+1, replace = TRUE)}
  start=(sum(!is.na(data$group))+1)
  data$group[start:nrow(data)]=NA
  for (i in start:nrow(data))
  { if (!missing(categorical.covariates))
  {for (j in 1:length(categorical.covariates))
  {
    NN.out=FNN.out(data, i, categorical.covariates[j], ratio, categorical.weights[j])
    NN.out[[1]][[2]]=NN.out[[1]][[2]]/sum(NN.out[[1]][[2]])
    if (j==1) {PP=NN.out[[1]][[2]]} else
    {PP=PP*NN.out[[1]][[2]]}
  }
  }

    if (contin&i>start.number)
    {
      for (k in 1:length(continuous.covariates))
      {cont=data[1:i,continuous.covariates[k]]
      ncc=quantile(cont, seq(0,1, length.out=qk[k]))
      ncc=ncc[-c(1, length(ncc))]
      data$ccont=1
      for (l in 1:length(ncc))
      {data$ccont[cont>ncc[l]]=(l+1)
      }
      CNN.out=FNN.out(data, i, "ccont", ratio, continuous.weights[k])

      CNN.out[[1]][[2]]=CNN.out[[1]][[2]]/sum(CNN.out[[1]][[2]])
      if (CNN.out[[2]]==1) {qk[k]=qk[k]+1}
      if (k==1) {cPP=CNN.out[[1]][[2]]} else
      {cPP=cPP*CNN.out[[1]][[2]]}
      }}

    PPP=PP*cPP
    PPP=PPP/sum(PPP)
    nc=min((nrow(data)-length(group.level)), (pct.determinstic *nrow(data)))
    if (i> nc)
    {pwhtrt=sample(group.level, 1, prob=PPP^(seq(2, 9, length.out = nrow(data)-nc)[i-nc]))} else
    {pwhtrt=sample(group.level, 1, prob=PPP)}

    data$group[i]=sample(pwhtrt,1)
  }
  return(data$group)
}

