#' BayCAR Package
#'
#' Contains three functions.
#'
#' @docType package
#'
#' @author Shengping Yang and Jianrong Wu
#'
#' @name BayCAR
#' NULL
