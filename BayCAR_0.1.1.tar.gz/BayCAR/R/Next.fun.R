#' The FUN.BCAR function
#'
#' @param frq  A list of counts of the number of subject in each group.
#'
#' @export

Next.fun=function(frq)
{if (all(frq==0)) {frq=1+frq}

  if (length(frq)==2)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2 )
  }

  if (length(frq)==3)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3)
  }

  if (length(frq)==4)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*dbeta(x, sum(frq)-frq[4]+.5, frq[4]+1+.5)}
  P4=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3, P4)
  }

  if (length(frq)==5)
  {integrand = function(x)
  {pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[1]+.5, frq[1]+1+.5)}
  P1=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[2]+.5, frq[2]+1+.5)}
  P2=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[3]+.5, frq[3]+1+.5)}
  P3=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[5]+1+.5, frq[5]+.5)*dbeta(x, sum(frq)-frq[4]+.5, frq[4]+1+.5)}
  P4=integrate(integrand, lower=0, upper=1)$value
  integrand = function(x)
  {pbeta(x, sum(frq)-frq[1]+1+.5, frq[1]+.5) *pbeta(x, sum(frq)-frq[2]+1+.5, frq[2]+.5)*pbeta(x, sum(frq)-frq[3]+1+.5, frq[3]+.5)*pbeta(x, sum(frq)-frq[4]+1+.5, frq[4]+.5)*dbeta(x, sum(frq)-frq[5]+.5, frq[5]+1+.5)}
  P5=integrate(integrand, lower=0, upper=1)$value
  allP=c(P1, P2, P3, P4, P5)
  }

  if (all(allP==0)) {allP=1+allP}

  whtrt= names(as.data.frame(frq))[which(allP==max(allP))]
  whtrt=sample(whtrt,1)
  return(list(whtrt, allP))
}
