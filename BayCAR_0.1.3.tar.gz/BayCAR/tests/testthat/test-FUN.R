test_that("Expected length", {
  expect_length(FUN.BCAR(data = data.frame("gender" = sample(c("female", "male"), 100, TRUE, c(.5, .5)), "age" = sample(c("<=50", ">50"), 100, TRUE, c(.5, .5)),categorical.covariates = c("gender", "age"), group.var=NA)), 100)
})
