library(testthat)
library(BayCAR)

test_check("BayCAR")
